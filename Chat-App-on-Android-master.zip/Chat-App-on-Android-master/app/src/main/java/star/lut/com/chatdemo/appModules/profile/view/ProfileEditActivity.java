package star.lut.com.chatdemo.appModules.profile.view;

import android.os.Bundle;

import star.lut.com.chatdemo.Base.BaseActivity;
import star.lut.com.chatdemo.R;

public class ProfileEditActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public int getLayout() {
        return R.layout.activity_profile_edit;
    }
}
