package star.lut.com.chatdemo.appModules.chatDetails.presenter;

public interface NewMessageReceived {
    void newMessageReceived();
}
