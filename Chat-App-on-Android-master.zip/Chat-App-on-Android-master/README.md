# Chat-App-on-Android
A chat apps built on android with PHP, MySQL backend using Firebase instant messaging.


A simple chat application build on Android using MySQL database, PHP backend. Firebase instant messaging was used to create the instant messaging service.

known bugs: it will post two notification for each message if the app is in background. 
