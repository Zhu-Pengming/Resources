package com.github.nkzawa.socketio.androidchat;

public class Constants {
    public static final String CHAT_SERVER_URL = "https://socket-io-chat.now.sh/";
}
